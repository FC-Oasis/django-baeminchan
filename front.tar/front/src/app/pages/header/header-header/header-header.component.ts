import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-header',
  templateUrl: './header-header.component.html',
  styleUrls: ['./header-header.component.css']
})
export class HeaderHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
